# AI Tutor App

An AI-powered tutoring platform where teachers upload PDFs and students interact with a GPT tutor trained on those notes.